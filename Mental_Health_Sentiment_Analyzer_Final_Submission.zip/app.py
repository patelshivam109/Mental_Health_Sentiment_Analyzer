from pathlib import Path
import re

import joblib
import pandas as pd
import streamlit as st
from textblob import TextBlob


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "Data"
REPORTS_DIR = ROOT / "reports"
VISUALS_DIR = ROOT / "visuals"
MODELS_DIR = ROOT / "models"


st.set_page_config(
    page_title="Mental Health Sentiment Analyzer",
    page_icon="",
    layout="wide",
    initial_sidebar_state="expanded",
)


st.markdown(
    """
    <style>
    .block-container {
        padding-top: 1.5rem;
        padding-bottom: 2rem;
    }
    h1, h2, h3 {
        letter-spacing: 0;
    }
    [data-testid="stMetric"] {
        background: #f7f9fb;
        border: 1px solid #dfe5ec;
        border-radius: 8px;
        padding: 14px 16px;
    }
    .status-note {
        padding: 12px 14px;
        border-left: 4px solid #2f6f9f;
        background: #f4f8fb;
        color: #263442;
        border-radius: 4px;
        margin: 0.25rem 0 1rem;
    }
    .risk-note {
        padding: 12px 14px;
        border-left: 4px solid #c44e52;
        background: #fff6f6;
        color: #332528;
        border-radius: 4px;
        margin: 0.25rem 0 1rem;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


@st.cache_data
def load_data() -> tuple[pd.DataFrame, pd.DataFrame]:
    cleaned = pd.read_csv(DATA_DIR / "cleaned_survey.csv")
    comments = pd.read_csv(DATA_DIR / "processed_comments_sentiment.csv")
    return cleaned, comments


@st.cache_data
def load_report_csv(filename: str) -> pd.DataFrame:
    return pd.read_csv(REPORTS_DIR / filename)


@st.cache_resource
def load_model():
    return joblib.load(MODELS_DIR / "sentiment_tfidf_pipeline.pkl")


def image(path: str, caption: str | None = None) -> None:
    st.image(str(VISUALS_DIR / path), caption=caption, use_container_width=True)


def pct(value: float) -> str:
    return f"{value:.1f}%"


def final_sentiment_output(text: str, model_prediction: str) -> tuple[str, float, list[str]]:
    polarity = TextBlob(text).sentiment.polarity
    lowered = text.lower()
    risk_terms = [
        "anxious",
        "anxiety",
        "burnout",
        "burned out",
        "depressed",
        "depression",
        "overwhelmed",
        "stress",
        "stressed",
        "unsupported",
        "panic",
        "exhausted",
        "hopeless",
        "hate",
    ]
    matched_terms = [term for term in risk_terms if re.search(rf"\b{re.escape(term)}\b", lowered)]

    if polarity < -0.05 or matched_terms:
        return "Negative", polarity, matched_terms
    if polarity > 0.05:
        return "Positive", polarity, matched_terms
    return model_prediction, polarity, matched_terms


cleaned_df, comments_df = load_data()
model = load_model()
model_results = load_report_csv("sentiment_model_results.csv")
sentiment_dist = load_report_csv("sentiment_distribution.csv")


st.sidebar.title("Dashboard")
page = st.sidebar.radio(
    "View",
    [
        "Executive Overview",
        "Sentiment Analysis",
        "At-Risk Cohorts",
        "Model Performance",
        "Predict Sentiment",
        "Reports",
    ],
)

st.sidebar.divider()
st.sidebar.caption("Dataset")
st.sidebar.write(f"Cleaned survey rows: {len(cleaned_df):,}")
st.sidebar.write(f"Comment rows: {len(comments_df):,}")
st.sidebar.write("Model: TF-IDF + Logistic Regression")


st.title("Mental Health Sentiment Analyzer")
st.markdown(
    '<div class="status-note">NLP dashboard for employee mental health survey comments, sentiment trends, model performance, and at-risk cohort insights.</div>',
    unsafe_allow_html=True,
)


if page == "Executive Overview":
    positive = int(sentiment_dist.loc[sentiment_dist["Sentiment"] == "Positive", "Count"].sum())
    negative = int(sentiment_dist.loc[sentiment_dist["Sentiment"] == "Negative", "Count"].sum())
    neutral = int(sentiment_dist.loc[sentiment_dist["Sentiment"] == "Neutral", "Count"].sum())
    treatment_yes = int((cleaned_df["treatment"] == "Yes").sum())

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Survey Responses", f"{len(cleaned_df):,}")
    col2.metric("Usable Comments", f"{len(comments_df):,}")
    col3.metric("Treatment Yes", f"{treatment_yes:,}", pct(treatment_yes / len(cleaned_df) * 100))
    col4.metric("Negative Comments", f"{negative:,}", pct(negative / len(comments_df) * 100))

    st.subheader("Key Findings")
    c1, c2 = st.columns([1.1, 1])
    with c1:
        st.markdown(
            """
            - Employees with family history show higher treatment-seeking behavior.
            - Work interference is one of the clearest high-risk indicators.
            - Comment sentiment is mixed, with positive comments highest but a meaningful negative group present.
            - The dataset has limited free-text comments, so model output should support analysis, not replace human review.
            """
        )
    with c2:
        image("sentiment_distribution.png", "Sentiment distribution from processed comments")

    st.subheader("Workplace Mental Health Trends")
    a, b = st.columns(2)
    with a:
        image("treatment_distribution.png", "Treatment distribution")
    with b:
        image("work_interfere_distribution.png", "Work interference by treatment")


elif page == "Sentiment Analysis":
    st.subheader("Sentiment Distribution")
    col1, col2 = st.columns([1, 1])
    with col1:
        st.dataframe(sentiment_dist, use_container_width=True, hide_index=True)
        st.bar_chart(sentiment_dist.set_index("Sentiment")["Count"])
    with col2:
        image("sentiment_distribution.png")

    st.subheader("Sentiment Across Employee Groups")
    gender_sentiment = load_report_csv("sentiment_by_gender.csv")
    country_sentiment = load_report_csv("sentiment_by_country_top10.csv")
    g1, g2 = st.columns(2)
    with g1:
        st.write("By gender")
        st.dataframe(gender_sentiment, use_container_width=True, hide_index=True)
    with g2:
        st.write("Top countries by negative sentiment ratio")
        st.dataframe(country_sentiment, use_container_width=True, hide_index=True)

    st.subheader("Comment Explorer")
    sentiment_filter = st.multiselect(
        "Sentiment",
        ["Negative", "Neutral", "Positive"],
        default=["Negative", "Neutral", "Positive"],
    )
    filtered = comments_df[comments_df["sentiment"].isin(sentiment_filter)]
    st.dataframe(
        filtered[["Age", "Gender", "Country", "work_interfere", "treatment", "sentiment", "comments"]]
        .head(100),
        use_container_width=True,
        hide_index=True,
    )


elif page == "At-Risk Cohorts":
    st.subheader("At-Risk Cohort Indicators")
    st.markdown(
        '<div class="risk-note">High-risk groups are identified from treatment status, work interference, family history, age group, country, and negative comment sentiment. Role analysis is not included because the source dataset has no role/job-title column.</div>',
        unsafe_allow_html=True,
    )

    age = load_report_csv("treatment_by_age_group.csv")
    family = load_report_csv("treatment_by_family_history.csv")
    work = load_report_csv("treatment_by_work_interference.csv")

    c1, c2, c3 = st.columns(3)
    with c1:
        st.write("Treatment by age group")
        st.dataframe(age, use_container_width=True, hide_index=True)
    with c2:
        st.write("Treatment by family history")
        st.dataframe(family, use_container_width=True, hide_index=True)
    with c3:
        st.write("Treatment by work interference")
        st.dataframe(work, use_container_width=True, hide_index=True)

    st.subheader("Supporting Visualizations")
    v1, v2 = st.columns(2)
    with v1:
        image("family_history_distribution.png")
    with v2:
        image("age_distribution.png")

    v3, v4 = st.columns(2)
    with v3:
        image("country_distribution.png")
    with v4:
        image("gender_distribution.png")


elif page == "Model Performance":
    st.subheader("Model Comparison")
    st.dataframe(model_results, use_container_width=True, hide_index=True)

    best = model_results.sort_values(["Weighted F1", "Accuracy"], ascending=False).iloc[0]
    m1, m2, m3 = st.columns(3)
    m1.metric("Selected Model", best["Model"])
    m2.metric("Accuracy", f"{best['Accuracy']:.3f}")
    m3.metric("Weighted F1", f"{best['Weighted F1']:.3f}")

    c1, c2 = st.columns(2)
    with c1:
        image("sentiment_model_comparison.png")
    with c2:
        image("sentiment_confusion_matrix.png")

    st.markdown(
        '<div class="status-note">Logistic Regression was selected because it achieved the highest Weighted F1 score, which is a better selection metric than accuracy alone for this multi-class sentiment task.</div>',
        unsafe_allow_html=True,
    )


elif page == "Predict Sentiment":
    st.subheader("Analyze New Employee Feedback")
    text = st.text_area(
        "Employee comment",
        height=160,
        placeholder="Enter an employee survey comment here...",
    )
    if st.button("Predict Sentiment", type="primary"):
        if text.strip():
            model_prediction = model.predict([text.strip()])[0]
            prediction, polarity, matched_terms = final_sentiment_output(text.strip(), model_prediction)
            p1, p2, p3 = st.columns(3)
            p1.metric("Final Sentiment", prediction)
            p2.metric("Model Prediction", model_prediction)
            p3.metric("Polarity Score", f"{polarity:.3f}")

            if matched_terms:
                st.caption("Detected wellness risk terms: " + ", ".join(matched_terms))

            if prediction == "Negative":
                st.warning("This comment may need HR wellness review.")
            elif prediction == "Positive":
                st.success("This comment appears positive based on the sentiment analysis workflow.")
            else:
                st.info("This comment appears neutral based on the sentiment analysis workflow.")
        else:
            st.error("Please enter a comment before predicting.")

    st.caption("Model output is for project analysis only and is not a diagnosis or employment decision tool.")


elif page == "Reports":
    st.subheader("Documentation and Reports")
    report_files = {
        "Sentiment Analysis Report": "sentiment_analysis_report.md",
        "At-Risk Cohort Report": "at_risk_cohort_report.md",
        "HR Recommendations": "hr_recommendations.md",
        "Final Documentation Report": "final_documentation_report.md",
    }
    selected_report = st.selectbox("Report", list(report_files.keys()))
    report_path = REPORTS_DIR / report_files[selected_report]
    if report_path.exists():
        st.markdown(report_path.read_text(encoding="utf-8"))
    else:
        st.info("This report file has not been generated yet.")
